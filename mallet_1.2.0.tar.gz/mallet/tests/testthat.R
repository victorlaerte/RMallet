library(testthat)
library(mallet)
test_check("mallet")
